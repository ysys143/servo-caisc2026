# SERVO Cross-System Coding: Reliability and Counterexample Report

This report records the inter-coder reliability and the counterexample search
specified in `coding_protocol.md`. It is the auditable evidence behind the
cross-system table and behind the framing of the V-completeness claim. All
numbers are reproduced by `python3 compute_kappa.py` over `systems.csv`
(N = 6 systems, Coder A vs. independent blind Coder B).

## 1. Inter-coder reliability (Cohen's kappa)

| field          | raw agreement | Cohen's kappa |
|----------------|---------------|---------------|
| loop_status    | 0.83          | 0.74          |
| Vcompleteness  | 0.50          | 0.14          |
| Vsyntax        | 0.17          | 0.00          |
| Vsemantic      | 0.83          | 0.67          |
| Vempirical     | 0.67          | 0.00          |
| Vhuman         | 0.67          | 0.33          |
| Vcalibrated    | 1.00          | 1.00          |
| **mean**       | **0.67**      | **0.41**      |

### How to read these numbers

- **The decisive construct is the most robust.** `V_calibrated` -- whether the
  highest automated validation layer is reliably calibrated rather than a biased
  judge -- has perfect agreement (kappa = 1.0, 6/6). This is precisely the
  construct on which the V-completeness argument turns, so the central claim does
  not rest on a coder-dependent judgment.

- **Loop status is substantial (kappa = 0.74).** The single disagreement is
  Coscientist (Coder A: partial-task; Coder B: closed-wetlab) -- the exact
  boundary case the 3-boundary `loop_status` rubric was introduced to surface.
  The published value is adjudicated to partial-task against the source quote
  (the autonomous loop closes only inside a predefined optimization task; no
  autonomous novelty certification).

- **The aggregate `V_completeness` ordinal is noisy (kappa = 0.14; raw 0.50).**
  Disagreement is concentrated on two definitional questions:
  (a) does executing code count as a `V_syntax` (deterministic pass/fail) check?
  Coder A said no in every case; Coder B said yes for every computational
  system. (b) does a one-shot or single-measurement benchmark count as a
  `V_empirical` feedback layer? Coder B coded `V_empirical = 1` for every
  system; Coder A withheld it where the measurement does not re-enter ideation.
  Both disagreements are recorded, not hidden. The deeper cause is that the ordinal
  itself is a holistic judgment, not a mechanical function of the binary indicators:
  Coder A counts V_human toward the layer total (Robot Scientist, AI Scientist Nature
  2026) while Coder B discounts biased/auxiliary layers (Coscientist, Agent
  Laboratory), so 4 of 12 ordinals deviate from the strict automated-layer rule. The
  rubric (coding_protocol.md) now states this explicitly, which is why we rest the
  claim on the calibration construct (kappa = 1.0) rather than this ordinal.

- **The kappa paradox at N = 6.** `V_syntax` and `V_empirical` show kappa = 0
  despite non-trivial raw agreement (0.17 and 0.67). This is the standard
  degeneracy: when one coder's marginal is constant (A: all `V_syntax`=0;
  B: all `V_empirical`=1) the chance-corrected statistic collapses. With six
  systems kappa is unstable by construction, which is why the protocol commits
  in advance to reporting kappa as a transparency measure and raw agreement
  alongside it, not as a precision estimate of human-level reliability.

### Adjudication rule applied

Every disagreement was resolved against the source quote in `systems.csv`; the
adjudicated value is the published one. The largest substantive effect of
adjudication is that the conservative reading (Coder A) is the published
`V_completeness` column, so the cross-system pattern in the paper is the more
skeptical of the two codings, not the more favourable.

## 2. Counterexample search

The protocol commits to actively seeking systems that would refute the claim,
in two directions. Three independent searches were run.

### (a) V-incomplete yet loop-closed (would refute necessity)

**Finding: no clean counterexample on the strong reading; one structural
near-miss.** The strongest candidate is **AI Scientist v1 (2024)**: it runs a
genuinely closed generate -> execute -> validate -> regenerate loop on an
*admittedly biased, uncalibrated* validator (LLM self-score + LLM reviewer at
~0.65 balanced accuracy). This refutes V-completeness as necessary for *loop
closure in the structural sense* (feedback does flow back into ideation). It
does **not** refute the claim on the substantive reading: the biased validator
yields unreliable, hallucination-prone output, so the loop closes without
reliably tracking truth. Every other V-incomplete system in the 2009-2026
corpus either (i) is rescued by a human at the final gate (Coscientist, Agent
Laboratory, DeepScientist) or (ii) closes only by switching to a near-oracle
validator (formal kernel, numeric evaluator, or wet-lab measurement: Robot
Scientist, FunSearch/AlphaEvolve, DeepSeek-Prover).

**Consequence for the paper.** This is the empirical basis for stating the
claim as an *association/correlate* ("V-completeness is the primary correlate of
closed-loop feasibility"), not as a deterministic law. The near-miss is reported
explicitly rather than suppressed.

### (b) V-complete yet loop-open for V-independent reasons (would refute sufficiency)

**Finding: no counterexample found.** Across systems with a genuinely
calibrated empirical validator across layers (Robot Scientist/Adam, A-Lab, the
mobile robotic chemist, closed-loop battery optimization), the loop *closes*
within scope. The only "openness" observed is a scope/economic choice
(fixed candidate list; human-in-the-loop for cost/safety/liability), not a
system property documented alongside a completeness claim. The category
"V-complete but open" is near-empty in the published record, which is itself
evidence for the direction of the association.

### (c) G/pi-driven closure with unimproved V (would weaken the V-centric framing)

**Finding: confirms rather than weakens.** In every closed-loop system that
gained capability from a stronger generator (G) or policy (pi) -- DeepScientist,
ERA, FunSearch/AlphaEvolve, DeepSeek-Prover -- the gain *exploited an
already-complete validator* (benchmark leaderboard, numeric oracle, or formal
kernel). The cleanest framing the evidence supports: **V-completeness gates
whether a closed loop is possible at all; G and pi gate how productive that loop
is once V is complete.** The one pure-G advance with no V improvement (OpenAI
unit-distance disproof) is *not* closed-loop -- it is single-shot, certified
post hoc by human mathematicians.

## 3. Net effect on the manuscript

1. The cross-system table is regenerated from `systems.csv` by
   `build_servo_tables.py`, which fails the build if any cell lacks a source
   quote or cites a key absent from `references.bib`.
2. The published coding is the conservative (Coder A) column; the more liberal
   Coder B reading would only strengthen the V-completeness pattern.
3. The central claim is stated as an association whose decisive sub-construct
   (calibration) has perfect inter-coder agreement, with the one structural
   counterexample (AI Scientist v1) reported in the limitations.
